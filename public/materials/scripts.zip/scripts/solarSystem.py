"""
solar_system.py  —  Blender 3.x / 4.x

Timeline (24 fps):
  1   –  40   Sun hero shot
  40  –  580  Planet tour  (9 planets × 60 frames each, including Pluto)
  580 –  640  Pull-back system reveal
  640 – 1120  Slow orbit showcase

KEY CHANGE: planets do NOT orbit the Sun until frame 600.
The orbit driver uses  max(0, frame - 600)  as its time input,
so every planet is frozen on the +X axis during the showcase.
"""

import bpy
import math
import random

# =========================================================
# CLEAN SCENE
# =========================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for block in bpy.data.meshes:    bpy.data.meshes.remove(block)
for block in bpy.data.materials: bpy.data.materials.remove(block)
for block in bpy.data.cameras:   bpy.data.cameras.remove(block)
for block in bpy.data.lights:    bpy.data.lights.remove(block)
for block in bpy.data.curves:    bpy.data.curves.remove(block)

# =========================================================
# RENDER SETTINGS
# =========================================================
scene = bpy.context.scene
scene.render.resolution_x          = 640
scene.render.resolution_y          = 360
scene.render.resolution_percentage = 100
scene.render.fps                   = 24
scene.render.engine                = 'BLENDER_EEVEE'
scene.cycles.samples               = 64
scene.cycles.use_denoising         = True
scene.render.film_transparent      = False

# =========================================================
# USER SETTINGS
# =========================================================
SCALE_DISTANCE   = 2.2
PLANET_SIZE_MULT = 1.2
TEXTURE_FOLDER   = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\\"

# --- Timeline ---
ORBIT_FREEZE_UNTIL = 600      # planets don't orbit before this frame

FRAMES_SUN        = 40        # Sun hero shot
FRAMES_PER_PLANET = 60        # per-planet showcase
FRAMES_PULLBACK   = 60        # sweep out to reveal full system
FRAMES_ORBIT      = 480       # slow orbit at end

N_PLANETS         = 9         # 8 classic + Pluto
TOUR_START        = FRAMES_SUN                                        #  40
PULLBACK_START    = TOUR_START + N_PLANETS * FRAMES_PER_PLANET        # 580
PULLBACK_END      = PULLBACK_START + FRAMES_PULLBACK                  # 640
SYSTEM_START      = PULLBACK_END                                      # 640
FRAME_END         = SYSTEM_START + FRAMES_ORBIT                       # 1120

# =========================================================
# PLANET DATA
# (name, radius, orbital_distance, orbit_speed, spin_speed,
#  texture_file, axial_tilt_deg, retrograde)
# =========================================================
PLANETS = [
    ("Mercury", 0.45,  4,  4.15, 0.8,  "mercury.jpg",   0,    False),
    ("Venus",   0.70,  6,  1.62, 0.6,  "venus.jpg",   177,    True),
    ("Earth",   0.75,  8,  1.00, 1.5,  "earth.jpg",  23.5,   False),
    ("Mars",    0.60, 10,  0.53, 1.4,  "mars.jpg",     25,    False),
    ("Jupiter", 2.30, 14,  0.084,3.5,  "jupiter.jpg",   3,    False),
    ("Saturn",  2.00, 18,  0.034,3.2,  "saturn.jpg",   27,    False),
    ("Uranus",  1.30, 22,  0.012,2.0,  "uranus.jpg",   98,    True),
    ("Neptune", 1.25, 26,  0.006,2.2,  "neptune.jpg",  28,    False),
    ("Pluto",   0.30, 32,  0.004,0.5,  "pluto.jpg",   57.5,  False),  # Pluto!
]

# =========================================================
# UTILITIES
# =========================================================
def load_tex(filename):
    try:
        return bpy.data.images.load(TEXTURE_FOLDER + filename, check_existing=True)
    except Exception:
        return None

def emission_material(name, tex_file, strength, fallback_color=(0.5, 0.5, 0.5, 1.0)):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    emit = nodes.new("ShaderNodeEmission")
    out  = nodes.new("ShaderNodeOutputMaterial")
    emit.inputs["Strength"].default_value = strength

    img = load_tex(tex_file) if tex_file else None
    if img:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = img
        links.new(tex.outputs["Color"], emit.inputs["Color"])
    else:
        emit.inputs["Color"].default_value = fallback_color

    links.new(emit.outputs["Emission"], out.inputs["Surface"])
    return mat

def smooth_all_fcurves(obj):
    if not (obj.animation_data and obj.animation_data.action):
        return
    for fc in obj.animation_data.action.fcurves:
        for kp in fc.keyframe_points:
            kp.interpolation = 'BEZIER'
            kp.easing        = 'EASE_IN_OUT'

# =========================================================
# SUN
# =========================================================
bpy.ops.mesh.primitive_uv_sphere_add(radius=3, segments=64, ring_count=32, location=(0,0,0))
sun = bpy.context.object
sun.name = "Sun"
bpy.ops.object.shade_smooth()
sun.data.materials.append(
    emission_material("Sun_Mat", "sunmap.jpg", strength=12,
                      fallback_color=(1.0, 0.6, 0.1, 1.0))
)
drv = sun.driver_add("rotation_euler", 2).driver
drv.expression = "frame * 0.008"

# =========================================================
# LIGHTS
# =========================================================
bpy.ops.object.light_add(type='POINT', location=(0, 0, 0))
sun_light = bpy.context.object
sun_light.name = "SunLight"
sun_light.data.energy           = 8000
sun_light.data.shadow_soft_size = 3.0
sun_light.data.use_shadow       = True

bpy.ops.object.light_add(type='SUN', location=(0, 0, 50))
fill = bpy.context.object
fill.name = "AmbientFill"
fill.data.energy     = 0.04
fill.data.angle      = math.radians(180)
fill.data.use_shadow = False

# =========================================================
# PLANETS
# Orbits are FROZEN until frame ORBIT_FREEZE_UNTIL.
# The driver expression uses  t = max(0, frame - ORBIT_FREEZE_UNTIL)
# so rotation stays 0 during the planet showcase and ramps up after.
# =========================================================
planet_objects = {}
orbit_empties  = {}

for name, size, dist, orbit_spd, spin_spd, tex, tilt, retro in PLANETS:

    # Orbit pivot empty
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    orb = bpy.context.object
    orb.name = name + "_Orbit"
    orbit_empties[name] = orb

    # Orbit driver — frozen until ORBIT_FREEZE_UNTIL, then accelerates
    drv_o = orb.driver_add("rotation_euler", 2).driver
    t_var = drv_o.variables.new()
    t_var.name = "f"
    t_var.targets[0].id_type = 'SCENE'
    t_var.targets[0].id      = scene
    t_var.targets[0].data_path = "frame_current"
    # t = frames elapsed since freeze lifted; orbit ramps up from 0
    drv_o.expression = (
        f"{orbit_spd} * 40 * (1 - cos(max(0, f - {ORBIT_FREEZE_UNTIL}) "
        f"/ {FRAME_END} * 1.5708))"
    )

    # Planet sphere
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=size * PLANET_SIZE_MULT,
        segments=64, ring_count=32,
        location=(dist * SCALE_DISTANCE, 0, 0)
    )
    planet = bpy.context.object
    planet.name = name
    bpy.ops.object.shade_smooth()
    planet_objects[name] = planet

    planet.data.materials.append(
        emission_material(name + "_Mat", tex, strength=1.5)
    )
    planet.parent = orb
    planet.matrix_parent_inverse = orb.matrix_world.inverted()
    planet.rotation_euler[0] = math.radians(tilt)

    # Self-spin (always active — looks good even while frozen in orbit)
    spin_dir = -1 if retro else 1
    drv_s = planet.driver_add("rotation_euler", 2).driver
    drv_s.expression = f"frame * {spin_dir * spin_spd} * 0.05"

    # =====================================================
    # Saturn Rings (7-band version)
    # =====================================================
    if name == "Saturn":

        # (Outer Radius, Ring Thickness)
        ring_data = [
            (2.90, 0.05),   # D Ring
            (3.15, 0.06),   # C Ring
            (3.45, 0.08),   # B Ring
            (3.78, 0.06),   # Cassini Division (thin)
            (4.05, 0.08),   # A Ring
            (4.35, 0.05),   # F Ring
            (4.65, 0.04),   # G/E Ring
        ]

        for i, (major, minor) in enumerate(ring_data):

            bpy.ops.object.select_all(action='DESELECT')

            bpy.ops.mesh.primitive_torus_add(
                align='WORLD',
                location=(dist * SCALE_DISTANCE, 0, 0),
                major_radius=major,
                minor_radius=minor,
                major_segments=160,
                minor_segments=12
            )

            ring = bpy.context.object
            ring.name = f"SaturnRing_{i+1}"

            # Make rings very thin
            ring.scale[2] = 0.025

            # Match Saturn's axial tilt
            ring.rotation_euler[0] = math.radians(27)

            # Parent to Saturn so rings move and rotate with it
            ring.parent = planet
            ring.matrix_parent_inverse = planet.matrix_world.inverted()

            # Slight brightness variation
            strength = 1.35 - (i * 0.08)

            ring.data.materials.append(
                emission_material(
                    f"SaturnRing_Mat_{i}",
                    "saturn_ring.png",
                    strength=strength,
                    fallback_color=(0.88, 0.78, 0.62, 1.0)
                )
            )

            # Optional: very slow texture/ring rotation
            drv = ring.driver_add("rotation_euler", 2).driver
            drv.expression = "frame * 0.0015"
            
# =========================================================
# EARTH'S MOON
# =========================================================
earth_orb  = orbit_empties["Earth"]
earth_dist = 8 * SCALE_DISTANCE

bpy.ops.object.empty_add(type='PLAIN_AXES', location=(earth_dist, 0, 0))
moon_orb = bpy.context.object
moon_orb.name = "Moon_Orbit"
moon_orb.parent = earth_orb
moon_orb.matrix_parent_inverse = earth_orb.matrix_world.inverted()

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.mesh.primitive_uv_sphere_add(
    radius=0.22, segments=32, ring_count=16,
    location=(earth_dist + 1.8, 0, 0)
)
moon = bpy.context.object
moon.name = "Moon"
bpy.ops.object.shade_smooth()
moon.data.materials.append(
    emission_material("Moon_Mat", "moon.jpg", strength=0.8,
                      fallback_color=(0.75, 0.75, 0.75, 1.0))
)
moon.parent = moon_orb
moon.matrix_parent_inverse = moon_orb.matrix_world.inverted()

# Moon orbit also frozen until ORBIT_FREEZE_UNTIL
drv_m = moon_orb.driver_add("rotation_euler", 2).driver
mv = drv_m.variables.new()
mv.name = "f"
mv.targets[0].id_type  = 'SCENE'
mv.targets[0].id       = scene
mv.targets[0].data_path = "frame_current"
drv_m.expression = f"max(0, f - {ORBIT_FREEZE_UNTIL}) * 0.25"

# =========================================================
# ORBIT GUIDE RINGS  (one per planet including Pluto)
# =========================================================
for name, size, dist, *_ in PLANETS:
    bpy.ops.curve.primitive_bezier_circle_add(
        radius=dist * SCALE_DISTANCE, location=(0, 0, 0)
    )
    ov = bpy.context.object
    ov.name = name + "_OrbitPath"
    ov.data.bevel_depth      = 0.012
    ov.data.bevel_resolution = 2
    ov.data.resolution_u     = 64

    om = bpy.data.materials.new(name + "_OrbitMat")
    om.use_nodes = True
    on = om.node_tree.nodes; ol = om.node_tree.links; on.clear()
    oe = on.new("ShaderNodeEmission"); oo = on.new("ShaderNodeOutputMaterial")
    oe.inputs["Color"].default_value    = (0.3, 0.5, 0.8, 1.0)
    oe.inputs["Strength"].default_value = 0.3
    ol.new(oe.outputs["Emission"], oo.inputs["Surface"])
    ov.data.materials.append(om)

# =========================================================
# STAR BACKGROUND
# =========================================================
world = bpy.context.scene.world
world.use_nodes = True
wn = world.node_tree.nodes; wl = world.node_tree.links; wn.clear()
wb  = wn.new("ShaderNodeBackground")
wev = wn.new("ShaderNodeTexEnvironment")
wou = wn.new("ShaderNodeOutputWorld")
img = load_tex("2k_stars.jpg")
if img:
    wev.image = img
    wl.new(wev.outputs["Color"], wb.inputs["Color"])
else:
    wb.inputs["Color"].default_value = (0.01, 0.01, 0.03, 1.0)
wl.new(wb.outputs["Background"], wou.inputs["Surface"])
wb.inputs["Strength"].default_value = 1.3

# =========================================================
# SHOOTING STARS
# =========================================================
random.seed(42)

NUM_STARS = 90
TRAVEL_DISTANCE = 110

for i in range(NUM_STARS):

    # Spawn from one of the four corners
    corner = random.randint(0, 3)

    if corner == 0:
        xs = random.uniform(-90, -70)
        ys = random.uniform(70, 90)

    elif corner == 1:
        xs = random.uniform(70, 90)
        ys = random.uniform(70, 90)

    elif corner == 2:
        xs = random.uniform(-90, -70)
        ys = random.uniform(-90, -70)

    else:
        xs = random.uniform(70, 90)
        ys = random.uniform(-90, -70)

    zs = random.uniform(-15, 15)

    dx = (-xs / abs(xs)) * TRAVEL_DISTANCE + random.uniform(-15, 15)
    dy = (-ys / abs(ys)) * TRAVEL_DISTANCE + random.uniform(-15, 15)
    dz = random.uniform(-6, 6)

    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=0.12,
        segments=8,
        ring_count=4,
        location=(xs, ys, zs)
    )

    star = bpy.context.object
    star.name = f"ShootingStar_{i:02d}"

    # Long streak
    star.scale = (1, 1, 12)

    # Orient toward movement
    length = math.sqrt(dx*dx + dy*dy + dz*dz)

    if length > 0:

        nx = dx / length
        ny = dy / length
        nz = dz / length

        dot = nz
        angle = math.acos(max(-1, min(1, dot)))

        rx = -ny
        ry = nx

        rlen = math.sqrt(rx*rx + ry*ry)

        if rlen > 0.001:

            rx /= rlen
            ry /= rlen

            star.rotation_euler = (
                rx * angle,
                ry * angle,
                0
            )

    mat = bpy.data.materials.new(f"StarMat_{i}")

    mat.use_nodes = True

    n = mat.node_tree.nodes
    l = mat.node_tree.links

    n.clear()

    emit = n.new("ShaderNodeEmission")
    out = n.new("ShaderNodeOutputMaterial")

    emit.inputs["Color"].default_value = (1.0, 0.95, 0.85, 1.0)
    emit.inputs["Strength"].default_value = 10

    l.new(emit.outputs["Emission"], out.inputs["Surface"])

    star.data.materials.append(mat)

    fire = random.randint(1, FRAME_END - 40)
    life = random.randint(30, 45)

    star.hide_render = True
    star.hide_viewport = True

    star.keyframe_insert("hide_render", frame=1)
    star.keyframe_insert("hide_viewport", frame=1)

    star.hide_render = False
    star.hide_viewport = False

    star.keyframe_insert("hide_render", frame=fire)
    star.keyframe_insert("hide_viewport", frame=fire)

    star.location = (xs, ys, zs)
    star.keyframe_insert("location", frame=fire)

    star.location = (
        xs + dx,
        ys + dy,
        zs + dz
    )

    star.keyframe_insert("location", frame=fire + life)

    star.hide_render = True
    star.hide_viewport = True

    star.keyframe_insert("hide_render", frame=fire + life + 1)
    star.keyframe_insert("hide_viewport", frame=fire + life + 1)

# =========================================================
# CAMERA  —  Track To constraint, location keyframes only
# =========================================================
bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
cam_target = bpy.context.object
cam_target.name = "CamTarget"

bpy.ops.object.camera_add(location=(0, -20, 10))
camera = bpy.context.object
camera.name = "Camera"
camera.data.lens     = 35
camera.data.clip_end = 2000
bpy.context.scene.camera = camera

track = camera.constraints.new(type='TRACK_TO')
track.target     = cam_target
track.track_axis = 'TRACK_NEGATIVE_Z'
track.up_axis    = 'UP_Y'

camera.data.dof.use_dof        = True
camera.data.dof.focus_object   = cam_target
camera.data.dof.aperture_fstop = 5.6

def cam_key(frame, cam_loc, target_loc):
    bpy.context.scene.frame_set(frame)
    camera.location     = cam_loc
    cam_target.location = target_loc
    camera.keyframe_insert(data_path="location")
    cam_target.keyframe_insert(data_path="location")

# ------------------------------------------------------------------
# SEQ 1 — Sun hero shot  (frames 1 → 40)
# ------------------------------------------------------------------
cam_key(1,   (0, -12,  4),  (0, 0, 0))
cam_key(20,  (0, -15,  5),  (0, 0, 0))
cam_key(40,  (0, -19,  7),  (0, 0, 0))

# ------------------------------------------------------------------
# SEQ 2 — Planet tour  (frames 40 → 580, 60 frames per planet)
# Planets are frozen on +X axis (orbit=0), so camera positions
# are reliable: each planet is at (dist * SCALE_DISTANCE, 0, 0).
# ------------------------------------------------------------------
planet_cam_offsets = {
    # name         y_offset  z_offset   (camera sits behind & above planet)
    "Mercury":    (-5,   2),
    "Venus":      (-6,   2.5),
    "Earth":      (-7,   3),
    "Mars":       (-7,   3),
    "Jupiter":    (-13,  6),
    "Saturn":     (-17,  7),   # wide to capture rings
    "Uranus":     (-11,  5),
    "Neptune":    (-11,  5),
    "Pluto":      (-8,   3.5),
}

for idx, (name, size, dist, *_rest) in enumerate(PLANETS):
    px = dist * SCALE_DISTANCE
    dy, dz = planet_cam_offsets[name]

    f_start = TOUR_START + idx * FRAMES_PER_PLANET       # arrival
    f_mid   = f_start + FRAMES_PER_PLANET // 3           # settle (straight-on)
    f_end   = f_start + FRAMES_PER_PLANET                # depart

    cam_key(f_start, (px - 3, dy,        dz),      (px, 0, 0))  # slide in from left
    cam_key(f_mid,   (px,     dy,        dz),      (px, 0, 0))  # steady centre frame
    cam_key(f_end,   (px + 3, dy * 0.85, dz),      (px, 0, 0))  # ease out to right

# ------------------------------------------------------------------
# SEQ 3 — Pull-back system reveal  (frames 580 → 640)
# Pluto is at 32 * 2.2 ≈ 70 units from origin.
# ------------------------------------------------------------------
cam_key(PULLBACK_START,      (70,  -35,  22),  (0, 0, 0))
cam_key(PULLBACK_START + 30, (0,   -90,  50),  (0, 0, 0))
cam_key(PULLBACK_END,        (0,  -125,  65),  (0, 0, 0))

# ------------------------------------------------------------------
# SEQ 4 — Slow 180° orbit  (frames 640 → 1120)
# Planets now orbit freely. Camera arcs around the whole system.
# ------------------------------------------------------------------
orbit_r = 130   # beyond Pluto's orbit ring
orbit_z = 65

steps = 7
for i in range(steps + 1):
    fframe = SYSTEM_START + i * (FRAMES_ORBIT // steps)
    angle  = math.radians(i * 180 / steps)
    cx     =  math.sin(angle) * orbit_r
    cy     = -math.cos(angle) * orbit_r
    cam_key(fframe, (cx, cy, orbit_z), (0, 0, 0))

cam_key(FRAME_END, (0, -orbit_r, orbit_z + 20), (0, 0, 0))

# Smooth easing on all camera keyframes
smooth_all_fcurves(camera)
smooth_all_fcurves(cam_target)

# =========================================================
# TIMELINE
# =========================================================
scene.frame_start = 1
scene.frame_end   = FRAME_END
bpy.context.scene.frame_set(1)

print("=" * 60)
print("Solar System — READY")
print(f"  Frames      : 1 – {FRAME_END}  ({FRAME_END // 24}s at 24fps)")
print(f"  Planets     : 9  (Mercury → Neptune + Pluto)")
print(f"  Orbits frozen until frame {ORBIT_FREEZE_UNTIL}, then active")
print("  Sequences:")
print(f"    1–{FRAMES_SUN:<4}      Sun hero shot")
for i, (n, *_) in enumerate(PLANETS):
    a = TOUR_START + i * FRAMES_PER_PLANET
    b = a + FRAMES_PER_PLANET
    print(f"    {a}–{b:<5}     {n}")
print(f"    {PULLBACK_START}–{PULLBACK_END:<5}     Pull-back system reveal")
print(f"    {SYSTEM_START}–{FRAME_END:<5}     Slow orbit showcase  ← orbits active")
print("=" * 60)