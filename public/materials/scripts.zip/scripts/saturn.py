# Saturn — with Moons
# Planets: Saturn + 9 major moons (Mimas, Enceladus, Tethys, Dione, Rhea,
#          Titan, Hyperion, Iapetus, Phoebe)

import bpy
import math
import random

# ============================================================
# TEXTURE PATHS
# ============================================================

SATURN_TEXTURE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\saturn.jpg"
STAR_TEXTURE   = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\2k_stars.jpg"

# ============================================================
# SATURN SETTINGS
# ============================================================

SATURN_RADIUS = 3.0
SATURN_TILT   = 26.73
SATURN_SPIN   = 0.065

# ============================================================
# MOON DATA
# ============================================================
# Each entry: (name, orbit_radius, moon_radius, color_rgba, orbit_period_frames)
# orbit_radius is in Blender units (Saturn radius = 3.0)
# Orbits are scaled so the nearest moon clears the outermost ring (~7.0 units)
# Orbital periods are proportional to real Keplerian values (Titan = 16-day base)
# Tidal locking: spin_rate = orbit angular speed (one face always toward Saturn)

MOONS = [
    # name,        orbit_r,  moon_r,  color (R,G,B,A),                period_frames
    ("Mimas",       9.0,     0.12,   (0.85, 0.85, 0.85, 1.0),          72),
    ("Enceladus",  10.5,     0.14,   (0.97, 0.97, 0.99, 1.0),          96),
    ("Tethys",     12.5,     0.22,   (0.88, 0.87, 0.84, 1.0),         120),
    ("Dione",      15.0,     0.23,   (0.82, 0.80, 0.76, 1.0),         156),
    ("Rhea",       19.0,     0.30,   (0.78, 0.75, 0.70, 1.0),         216),
    ("Titan",      30.0,     0.55,   (0.88, 0.64, 0.22, 1.0),         384),   # orange haze
    ("Hyperion",   37.0,     0.14,   (0.70, 0.65, 0.58, 1.0),         504),   # spongy, dark
    ("Iapetus",    65.0,     0.28,   (0.60, 0.55, 0.50, 1.0),        1056),   # two-tone
    ("Phoebe",    110.0,     0.12,   (0.28, 0.26, 0.24, 1.0),        3600),   # dark, distant
]

# ============================================================
# CLEAR SCENE
# ============================================================

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for collection in (
    bpy.data.meshes,
    bpy.data.materials,
    bpy.data.images,
    bpy.data.lights,
):
    for block in list(collection):
        if block.users == 0:
            collection.remove(block)

# ============================================================
# HELPERS
# ============================================================

def make_sphere(name, radius, location):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius,
        segments=128,
        ring_count=64,
        location=location
    )
    obj = bpy.context.object
    obj.name = name
    bpy.ops.object.shade_smooth()
    return obj


def make_material(name, texture):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    tex  = nodes.new("ShaderNodeTexImage")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    out  = nodes.new("ShaderNodeOutputMaterial")

    tex.location  = (-500, 0)
    bsdf.location = (-100, 0)
    out.location  = ( 250, 0)

    try:
        tex.image = bpy.data.images.load(texture, check_existing=True)
    except:
        print("Couldn't load", texture)

    bsdf.inputs["Roughness"].default_value = 0.85
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.08

    links.new(tex.outputs["Color"],  bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"],  out.inputs["Surface"])
    return mat


def make_flat_color_material(name, color):
    """Simple PBR material with a flat base color — used for moons."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    noise  = nodes.new("ShaderNodeTexNoise")
    ramp   = nodes.new("ShaderNodeValToRGB")
    bsdf   = nodes.new("ShaderNodeBsdfPrincipled")
    out    = nodes.new("ShaderNodeOutputMaterial")

    noise.location  = (-500, 0)
    ramp.location   = (-270, 0)
    bsdf.location   = (  60, 0)
    out.location    = ( 350, 0)

    # Subtle surface variation so moons don't look like plain spheres
    noise.inputs["Scale"].default_value     = 8.0
    noise.inputs["Detail"].default_value    = 4.0
    noise.inputs["Roughness"].default_value = 0.6

    r, g, b, a = color
    ramp.color_ramp.elements[0].color = (r * 0.80, g * 0.80, b * 0.80, 1)
    ramp.color_ramp.elements[1].color = (r,        g,        b,        1)

    bsdf.inputs["Roughness"].default_value = 0.92
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.02

    links.new(noise.outputs["Fac"],   ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"],  bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"],   out.inputs["Surface"])
    return mat


def add_driver(obj, path, index, expression):
    drv = obj.driver_add(path, index).driver
    drv.expression = expression


def make_orbit_ring(name, radius, tilt_deg):
    """Thin torus guide ring showing a moon's orbital path."""
    bpy.ops.mesh.primitive_torus_add(
        major_radius=radius,
        minor_radius=0.018,
        major_segments=128,
        minor_segments=8,
        location=(0, 0, 0)
    )
    ring = bpy.context.object
    ring.name = name
    ring.rotation_euler[0] = math.radians(tilt_deg)

    mat = bpy.data.materials.new(name + "_Mat")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    emit = nodes.new("ShaderNodeEmission")
    out  = nodes.new("ShaderNodeOutputMaterial")
    emit.inputs["Color"].default_value    = (0.3, 0.5, 0.7, 1)
    emit.inputs["Strength"].default_value = 0.18
    links.new(emit.outputs["Emission"], out.inputs["Surface"])

    ring.data.materials.append(mat)
    return ring


# ============================================================
# SATURN
# ============================================================

saturn = make_sphere("Saturn", SATURN_RADIUS, (0, 0, 0))
saturn.rotation_euler[0] = math.radians(SATURN_TILT)
saturn.data.materials.append(make_material("Saturn Material", SATURN_TEXTURE))

add_driver(saturn, "rotation_euler", 2, f"frame*{SATURN_SPIN}")

# ============================================================
# SATURN RINGS
# ============================================================

ring_specs = [
    (3.70, 0.040, (0.92, 0.88, 0.78, 1)),
    (4.05, 0.060, (0.83, 0.79, 0.68, 1)),
    (4.45, 0.045, (0.96, 0.93, 0.84, 1)),
    (4.95, 0.090, (0.76, 0.73, 0.63, 1)),
    (5.55, 0.070, (0.91, 0.88, 0.80, 1)),
    (6.20, 0.120, (0.82, 0.79, 0.70, 1)),
    (7.00, 0.060, (0.95, 0.92, 0.85, 1)),
]

for i, (radius, thickness, color) in enumerate(ring_specs):
    bpy.ops.mesh.primitive_torus_add(
        major_radius=radius,
        minor_radius=thickness,
        major_segments=256,
        minor_segments=24,
        location=(0, 0, 0)
    )
    ring = bpy.context.object
    ring.name = f"SaturnRing_{i+1}"
    ring.scale[2] = 0.018
    ring.rotation_euler[0] = math.radians(SATURN_TILT)
    bpy.ops.object.transform_apply(scale=True)

    mat = bpy.data.materials.new(f"RingMaterial_{i+1}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    texcoord = nodes.new("ShaderNodeTexCoord")
    mapping  = nodes.new("ShaderNodeMapping")
    noise    = nodes.new("ShaderNodeTexNoise")
    ramp     = nodes.new("ShaderNodeValToRGB")
    bsdf     = nodes.new("ShaderNodeBsdfPrincipled")
    output   = nodes.new("ShaderNodeOutputMaterial")

    texcoord.location = (-900, 0)
    mapping.location  = (-700, 0)
    noise.location    = (-450, 0)
    ramp.location     = (-180, 0)
    bsdf.location     = ( 120, 0)
    output.location   = ( 420, 0)

    noise.inputs["Scale"].default_value     = 140
    noise.inputs["Detail"].default_value    = 2.5
    noise.inputs["Roughness"].default_value = 0.55

    ramp.color_ramp.elements[0].position = 0.42
    ramp.color_ramp.elements[1].position = 0.58
    ramp.color_ramp.elements[0].color = (color[0]*0.72, color[1]*0.72, color[2]*0.72, 1)
    ramp.color_ramp.elements[1].color = color

    bsdf.inputs["Base Color"].default_value = color
    bsdf.inputs["Roughness"].default_value  = 0.95
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.01

    links.new(texcoord.outputs["Object"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"],  noise.inputs["Vector"])
    links.new(noise.outputs["Fac"],       ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"],      bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"],       output.inputs["Surface"])

    ring.data.materials.append(mat)
    ring.parent = saturn
    ring.matrix_parent_inverse = saturn.matrix_world.inverted()

# ============================================================
# MOONS
# ============================================================
# Each moon uses an Empty pivot at the origin to drive orbital motion.
# A driver on the pivot's Z-rotation produces a smooth circular orbit.
# Tidal-lock spin: the moon's own Z-rotation mirrors the pivot so one
# face always points toward Saturn.
#
# Orbital inclination: real moons have small inclinations (≤1–2°) except
# Hyperion (~0.6°), Iapetus (~15°), Phoebe (~175°, retrograde).
# We honour these three notable cases; the rest get 0°.

MOON_INCLINATIONS = {
    "Iapetus": 15.0,
    "Phoebe": 175.0,   # retrograde — negative angular speed below
}

# Phoebe orbits retrograde, so its angular speed is negative.
RETROGRADE = {"Phoebe"}

moon_objects = []

for moon_name, orbit_r, moon_r, color, period in MOONS:
    # ── Orbit guide ring ────────────────────────────────────
    incl = MOON_INCLINATIONS.get(moon_name, 0.0)
    orbit_guide = make_orbit_ring(f"{moon_name}_OrbitRing", orbit_r, incl)

    # ── Pivot empty ─────────────────────────────────────────
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    pivot = bpy.context.object
    pivot.name = f"{moon_name}_Pivot"
    pivot.rotation_euler[0] = math.radians(incl)

    # Angular speed (radians per frame) = 2π / period
    ang_speed = 2 * math.pi / period
    if moon_name in RETROGRADE:
        ang_speed = -ang_speed

    add_driver(pivot, "rotation_euler", 2, f"frame*{ang_speed}")

    # ── Moon sphere ─────────────────────────────────────────
    moon = make_sphere(moon_name, moon_r, (orbit_r, 0, 0))
    moon.data.materials.append(make_flat_color_material(f"{moon_name}_Mat", color))

    # Tidal-lock: spin at same rate as orbit so same face always points in
    add_driver(moon, "rotation_euler", 2, f"frame*{ang_speed}")

    # Parent moon to its pivot so it inherits orbital rotation
    moon.parent = pivot
    moon.matrix_parent_inverse = pivot.matrix_world.inverted()

    moon_objects.append(moon)

    print(f"  Moon added: {moon_name}  orbit={orbit_r:.1f}u  r={moon_r}u  period={period}f")

# ============================================================
# STAR BACKGROUND
# ============================================================

world = bpy.context.scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
nodes.clear()

env = nodes.new("ShaderNodeTexEnvironment")
bg  = nodes.new("ShaderNodeBackground")
out = nodes.new("ShaderNodeOutputWorld")

env.location = (-400, 0)
bg.location  = (-120, 0)
out.location = ( 200, 0)

try:
    env.image = bpy.data.images.load(STAR_TEXTURE, check_existing=True)
    links.new(env.outputs["Color"], bg.inputs["Color"])
except:
    bg.inputs["Color"].default_value = (0.01, 0.01, 0.03, 1)

bg.inputs["Strength"].default_value = 1.35
links.new(bg.outputs["Background"], out.inputs["Surface"])

# ============================================================
# SUN LIGHT
# ============================================================

bpy.ops.object.light_add(type='SUN', location=(30, -25, 20))
sun = bpy.context.object
sun.name = "Sun Light"
sun.data.energy = 6.5
sun.data.angle  = math.radians(0.5)
sun.rotation_euler = (math.radians(-55), math.radians(8), math.radians(35))

# ============================================================
# FILL LIGHT
# ============================================================

bpy.ops.object.light_add(type='AREA', location=(-18, 16, 12))
fill = bpy.context.object
fill.name = "Fill Light"
fill.data.energy = 450
fill.data.shape  = 'RECTANGLE'
fill.data.size   = 15
fill.data.size_y = 15
fill.rotation_euler = (math.radians(80), 0, math.radians(-40))

# ============================================================
# RIM LIGHT
# ============================================================

bpy.ops.object.light_add(type='AREA', location=(-30, -15, 18))
rim = bpy.context.object
rim.name = "Rim Light"
rim.data.energy = 250
rim.data.shape  = 'RECTANGLE'
rim.data.size   = 18
rim.data.size_y = 18
rim.rotation_euler = (math.radians(65), 0, math.radians(130))

# ============================================================
# CAMERA
# ============================================================

bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
focus = bpy.context.object
focus.name = "Camera Focus"

bpy.ops.object.camera_add(location=(-24, 18, 8))
camera = bpy.context.object
camera.name = "Camera"
# Wider FOV (35 mm) so all inner moons (out to Rhea at orbit=19u) fit in frame.
# The longer distance keeps Saturn large enough to read as the hero.
camera.data.lens     = 60
camera.data.clip_end = 5000

track = camera.constraints.new(type='TRACK_TO')
track.target     = focus
track.track_axis = 'TRACK_NEGATIVE_Z'
track.up_axis    = 'UP_Y'

camera.data.dof.use_dof        = True
camera.data.dof.focus_object   = focus
# Open aperture a little vs before so distant moons aren't completely blurred.
camera.data.dof.aperture_fstop = 5.6

bpy.context.scene.camera = camera

# ============================================================
# CAMERA ANIMATION  (cinematic float)
# ============================================================

scene = bpy.context.scene

keyframes = [
    (  1, (-65, 48,  22.0)),
    ( 80, (-60, 52,  24.0)),
    (160, (-55, 56,  26.0)),
    (250, (-65, 48,  22.0)),
]

for frame, loc in keyframes:
    scene.frame_set(frame)
    camera.location = loc
    camera.keyframe_insert("location")

focus.location = (0, 0, 0)
focus.keyframe_insert("location", frame=1)
focus.keyframe_insert("location", frame=250)

def smooth_fcurves(obj):
    if obj.animation_data and obj.animation_data.action:
        for fc in obj.animation_data.action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = 'BEZIER'
                kp.easing        = 'EASE_IN_OUT'

smooth_fcurves(camera)
smooth_fcurves(focus)

# ============================================================
# RENDER SETTINGS
# ============================================================

scene.render.engine             = 'BLENDER_EEVEE'
scene.render.resolution_x       = 960
scene.render.resolution_y       = 540
scene.render.resolution_percentage = 100
scene.render.fps                = 24
scene.frame_start               = 1
scene.frame_end                 = 250

if hasattr(scene.eevee, "taa_render_samples"):
    scene.eevee.taa_render_samples = 128
if hasattr(scene.eevee, "use_gtao"):
    scene.eevee.use_gtao   = True
if hasattr(scene.eevee, "use_bloom"):
    scene.eevee.use_bloom  = True
if hasattr(scene.eevee, "use_ssr"):
    scene.eevee.use_ssr    = True

# ============================================================
# SATURN ATMOSPHERE GLOW
# ============================================================

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=SATURN_RADIUS * 1.03,
    segments=128,
    ring_count=64,
    location=(0, 0, 0)
)
glow = bpy.context.object
glow.name = "Atmosphere"
glow.parent = saturn
glow.matrix_parent_inverse = saturn.matrix_world.inverted()
bpy.ops.object.shade_smooth()

glow_mat = bpy.data.materials.new("AtmosphereGlow")
glow_mat.use_nodes    = True
glow_mat.blend_method = 'BLEND'
if hasattr(glow_mat, 'shadow_method'):
    glow_mat.shadow_method = 'NONE'

nodes = glow_mat.node_tree.nodes
links = glow_mat.node_tree.links
nodes.clear()

layer    = nodes.new("ShaderNodeLayerWeight")
ramp     = nodes.new("ShaderNodeValToRGB")
emission = nodes.new("ShaderNodeEmission")
output   = nodes.new("ShaderNodeOutputMaterial")

layer.location    = (-600, 0)
ramp.location     = (-350, 0)
emission.location = ( -80, 0)
output.location   = ( 180, 0)

layer.inputs["Blend"].default_value = 0.15
ramp.color_ramp.elements[0].position = 0.55
ramp.color_ramp.elements[1].position = 0.92
ramp.color_ramp.elements[0].color    = (0,    0,    0,   0)
ramp.color_ramp.elements[1].color    = (0.72, 0.82, 1.0, 1)
emission.inputs["Strength"].default_value = 0.45

links.new(layer.outputs["Facing"],      ramp.inputs["Fac"])
links.new(ramp.outputs["Color"],        emission.inputs["Color"])
links.new(emission.outputs["Emission"], output.inputs["Surface"])

glow.data.materials.append(glow_mat)

# ============================================================
# DISTANT STARS  (background particle field)
# ============================================================

random.seed(42)

star_mat = bpy.data.materials.new("BackgroundStars")
star_mat.use_nodes = True
nodes = star_mat.node_tree.nodes
links = star_mat.node_tree.links
nodes.clear()

emit = nodes.new("ShaderNodeEmission")
out  = nodes.new("ShaderNodeOutputMaterial")
emit.inputs["Color"].default_value    = (1, 1, 1, 1)
emit.inputs["Strength"].default_value = 3.5
links.new(emit.outputs["Emission"], out.inputs["Surface"])

for i in range(500):
    theta = random.uniform(0, math.pi * 2)
    phi   = random.uniform(0, math.pi)
    r     = random.uniform(140, 220)
    x = r * math.sin(phi) * math.cos(theta)
    y = r * math.sin(phi) * math.sin(theta)
    z = r * math.cos(phi)
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=random.uniform(0.03, 0.08),
        location=(x, y, z),
        segments=8,
        ring_count=4
    )
    star = bpy.context.object
    star.data.materials.append(star_mat)

# ============================================================
# SHOOTING STARS
# ============================================================

for i in range(15):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=0.06,
        location=(
            random.uniform(-120, 120),
            random.uniform(-120, 120),
            random.uniform(-30,   30)
        )
    )
    meteor = bpy.context.object
    meteor.scale = (1, 1, 10)
    meteor.data.materials.append(star_mat)

    start = random.randint(1, 190)
    end   = start + random.randint(50, 70)

    x, y, z = meteor.location.x, meteor.location.y, meteor.location.z

    meteor.hide_render   = True
    meteor.hide_viewport = True
    meteor.keyframe_insert("hide_render",   frame=1)
    meteor.keyframe_insert("hide_viewport", frame=1)

    meteor.hide_render   = False
    meteor.hide_viewport = False
    meteor.keyframe_insert("hide_render",   frame=start)
    meteor.keyframe_insert("hide_viewport", frame=start)

    meteor.location = (x, y, z)
    meteor.keyframe_insert("location", frame=start)

    meteor.location = (
        x + random.uniform(-45,  45),
        y - random.uniform( 60,  90),
        z + random.uniform( -6,   6)
    )
    meteor.keyframe_insert("location", frame=end)

    meteor.hide_render   = True
    meteor.hide_viewport = True
    meteor.keyframe_insert("hide_render",   frame=end + 1)
    meteor.keyframe_insert("hide_viewport", frame=end + 1)

# ============================================================
# RESET TO FRAME 1
# ============================================================

scene.frame_set(1)

# ============================================================
# SUMMARY
# ============================================================

print("=" * 60)
print("Saturn Scene — with Moons")
print("=" * 60)
print(f"Planet      : {saturn.name}")
print("Rings       : 7")
print(f"Moons       : {len(MOONS)}")
for moon_name, orbit_r, moon_r, color, period in MOONS:
    incl = MOON_INCLINATIONS.get(moon_name, 0.0)
    retro = " (retrograde)" if moon_name in RETROGRADE else ""
    print(f"  {moon_name:<12} orbit={orbit_r:>6.1f}u  r={moon_r:.2f}u  period={period}f  incl={incl}°{retro}")
print("Animation   : 250 Frames")
print("Renderer    : Eevee")
print("Camera      : Cinematic Float")
print("Lighting    : Three-Point Space")
print("=" * 60)