import bpy
import math
import mathutils

# ============================================================
# TEXTURE PATHS
# ============================================================

SUN_TEXTURE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\sunmap.jpg"
STAR_TEXTURE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\2k_stars.jpg"

# ============================================================
# CLEAR SCENE
# ============================================================

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# ============================================================
# WORLD
# ============================================================

world = bpy.data.worlds["World"]
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs["Strength"].default_value = 0

# ============================================================
# STAR SPHERE
# ============================================================

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=200, location=(0,0,0), segments=128, ring_count=64
)
stars = bpy.context.object
stars.name = "Stars"

bpy.context.view_layer.objects.active = stars
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.flip_normals()
bpy.ops.object.mode_set(mode='OBJECT')

star_mat = bpy.data.materials.new("StarsMaterial")
star_mat.use_nodes = True
nodes = star_mat.node_tree.nodes
links = star_mat.node_tree.links
nodes.clear()

tex      = nodes.new("ShaderNodeTexImage")
tex.image = bpy.data.images.load(STAR_TEXTURE)
coord    = nodes.new("ShaderNodeTexCoord")
mapping  = nodes.new("ShaderNodeMapping")
emission = nodes.new("ShaderNodeEmission")
emission.inputs["Strength"].default_value = 1.5
output   = nodes.new("ShaderNodeOutputMaterial")

links.new(coord.outputs["UV"], mapping.inputs["Vector"])
links.new(mapping.outputs["Vector"],  tex.inputs["Vector"])
links.new(tex.outputs["Color"],       emission.inputs["Color"])
links.new(emission.outputs["Emission"], output.inputs["Surface"])

stars.data.materials.append(star_mat)

# ============================================================
# SUN
# ============================================================

bpy.ops.mesh.primitive_uv_sphere_add(
    radius=2, location=(0,0,0), segments=128, ring_count=64
)
sun = bpy.context.object
sun.name = "Sun"

sun_mat = bpy.data.materials.new("SunMaterial")
sun_mat.use_nodes = True
nodes = sun_mat.node_tree.nodes
links = sun_mat.node_tree.links
nodes.clear()

tex      = nodes.new("ShaderNodeTexImage")
tex.image = bpy.data.images.load(SUN_TEXTURE)
coord    = nodes.new("ShaderNodeTexCoord")
mapping  = nodes.new("ShaderNodeMapping")
bsdf     = nodes.new("ShaderNodeBsdfPrincipled")
emission = nodes.new("ShaderNodeEmission")
emission.inputs["Strength"].default_value = 6
mix      = nodes.new("ShaderNodeAddShader")
output   = nodes.new("ShaderNodeOutputMaterial")

links.new(coord.outputs["UV"],        mapping.inputs["Vector"])
links.new(mapping.outputs["Vector"],  tex.inputs["Vector"])
links.new(tex.outputs["Color"],       bsdf.inputs["Base Color"])
links.new(tex.outputs["Color"],       emission.inputs["Color"])
links.new(bsdf.outputs["BSDF"],       mix.inputs[0])
links.new(emission.outputs["Emission"], mix.inputs[1])
links.new(mix.outputs["Shader"],      output.inputs["Surface"])

sun.data.materials.append(sun_mat)

# ============================================================
# SUN LIGHT
# ============================================================

bpy.ops.object.light_add(type='SUN', location=(0,0,10))
light = bpy.context.object
light.data.energy = 5

# ============================================================
# CAMERA
# ============================================================

def look_at_origin(cam):
    loc = cam.location.copy()
    direction = mathutils.Vector((0, 0, 0)) - loc
    rot = direction.to_track_quat('-Z', 'Y')
    cam.rotation_euler = rot.to_euler()

cam_data = bpy.data.cameras.new("Camera")
cam_data.lens = 50                          # fixed lens, no zoom
camera = bpy.data.objects.new("Camera", cam_data)
bpy.context.collection.objects.link(camera)
bpy.context.scene.camera = camera

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end   = 360                     # 15 seconds at 24fps

# ============================================================
# KEYFRAMES
# Camera slowly rises from below the Sun
# ============================================================

DIST = 20  # Constant distance

keyframes = [
    # frame    x      y         z
    (1,       0.0,   -DIST,   -4.0),  # Below the Sun
    (90,      0.0,   -DIST,   -2.0),
    (180,     0.0,   -DIST,    0.0),  # Level with the Sun
    (270,     0.0,   -DIST,    2.0),
    (360,     0.0,   -DIST,    4.0),  # Slightly above the Sun
]

for frame, x, y, z in keyframes:
    scene.frame_set(frame)
    camera.location = (x, y, z)
    look_at_origin(camera)

    camera.keyframe_insert(data_path="location", frame=frame)
    camera.keyframe_insert(data_path="rotation_euler", frame=frame)

# Smooth BEZIER easing
for fcurve in camera.animation_data.action.fcurves:
    for kp in fcurve.keyframe_points:
        kp.interpolation = 'BEZIER'
        
# ============================================================
# RENDER SETTINGS
# ============================================================

scene.render.engine = 'BLENDER_EEVEE'
scene.eevee.use_bloom = True
scene.eevee.bloom_intensity = 0.12
scene.eevee.bloom_radius = 6.5
scene.eevee.taa_render_samples = 64

print("Sun scene created successfully!")