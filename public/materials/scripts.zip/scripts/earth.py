import bpy
import math

# ============================================================
# TEXTURE PATHS
# ============================================================

EARTH_TEXTURE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\earth.jpg"
MOON_TEXTURE  = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\moon.jpg"
STAR_TEXTURE  = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\2k_stars.jpg"

# ============================================================
# SCALE
# ============================================================

EARTH_RADIUS = 2.0
MOON_RADIUS = 0.54
MOON_DISTANCE = 6.0

EARTH_TILT = 23.44

EARTH_SPIN = 0.0504
MOON_ORBIT = 0.0018
MOON_SPIN = MOON_ORBIT

# ============================================================
# CLEAR SCENE
# ============================================================

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for collection in (
    bpy.data.meshes,
    bpy.data.materials,
    bpy.data.images,
    bpy.data.lights,
):
    for block in collection:
        if block.users == 0:
            collection.remove(block)

# ============================================================
# HELPERS
# ============================================================

def make_sphere(name, radius, location):

    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius,
        segments=128,
        ring_count=64,
        location=location
    )

    obj = bpy.context.object
    obj.name = name

    bpy.ops.object.shade_smooth()

    return obj


def make_material(name, texture):

    mat = bpy.data.materials.new(name)

    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    nodes.clear()

    tex = nodes.new("ShaderNodeTexImage")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    out = nodes.new("ShaderNodeOutputMaterial")

    tex.location = (-500,0)
    bsdf.location = (-100,0)
    out.location = (250,0)

    try:
        tex.image = bpy.data.images.load(texture, check_existing=True)
    except:
        print("Couldn't load", texture)

    # Blender 5.1 Principled values
    bsdf.inputs["Roughness"].default_value = 0.8

    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.1

    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    return mat


def add_driver(obj, path, index, expression):

    drv = obj.driver_add(path, index).driver
    drv.expression = expression

# ============================================================
# EARTH
# ============================================================

earth = make_sphere(
    "Earth",
    EARTH_RADIUS,
    (0,0,0)
)

earth.rotation_euler[0] = math.radians(EARTH_TILT)

earth.data.materials.append(
    make_material(
        "Earth Material",
        EARTH_TEXTURE
    )
)

add_driver(
    earth,
    "rotation_euler",
    2,
    f"frame*{EARTH_SPIN}"
)

# ============================================================
# MOON ORBIT
# ============================================================

bpy.ops.object.empty_add(
    type='PLAIN_AXES',
    location=(0,0,0)
)

orbit = bpy.context.object
orbit.name = "Moon Orbit"

add_driver(
    orbit,
    "rotation_euler",
    2,
    f"frame*{MOON_ORBIT}"
)

moon = make_sphere(
    "Moon",
    MOON_RADIUS,
    (0,MOON_DISTANCE,0)
)

moon.parent = orbit
moon.matrix_parent_inverse = orbit.matrix_world.inverted()

moon.data.materials.append(
    make_material(
        "Moon Material",
        MOON_TEXTURE
    )
)

add_driver(
    moon,
    "rotation_euler",
    2,
    f"frame*{MOON_SPIN}"
)

# ============================================================
# STAR BACKGROUND
# ============================================================

world = bpy.context.scene.world
world.use_nodes = True

nodes = world.node_tree.nodes
links = world.node_tree.links

nodes.clear()

env = nodes.new("ShaderNodeTexEnvironment")
bg = nodes.new("ShaderNodeBackground")
out = nodes.new("ShaderNodeOutputWorld")

env.location=(-400,0)
bg.location=(-100,0)
out.location=(200,0)

try:
    env.image = bpy.data.images.load(
        STAR_TEXTURE,
        check_existing=True
    )
except:
    bg.inputs["Color"].default_value = (0.01,0.01,0.03,1)

bg.inputs["Strength"].default_value = 1.3

links.new(env.outputs["Color"], bg.inputs["Color"])
links.new(bg.outputs["Background"], out.inputs["Surface"])

# ============================================================
# SUN
# ============================================================

bpy.ops.object.light_add(
    type='SUN',
    location=(0,30,10)
)

sun = bpy.context.object

sun.data.energy = 5

sun.rotation_euler = (
    math.radians(-60),
    0,
    math.radians(0)
)

# ============================================================
# CAMERA
# ============================================================

bpy.ops.object.camera_add(
    location=(-20,20,5)
)

camera = bpy.context.object

camera.rotation_euler = (
    math.radians(80),
    0,
    math.radians(225)
)

camera.data.lens = 55

bpy.context.scene.camera = camera

# ============================================================
# RENDER
# ============================================================

scene = bpy.context.scene

scene.render.engine = 'BLENDER_EEVEE'
scene.cycles.samples = 256

scene.render.resolution_x = 640
scene.render.resolution_y = 360

scene.frame_start = 1
scene.frame_end = 250

print("Earth and Moon scene created successfully.")