import bpy
import math

BASE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures"
PLUTO_TEXTURE = BASE + r"\pluto.jpg"
STAR_TEXTURE  = BASE + r"\2k_stars.jpg"

PLUTO_RADIUS = 1.2
PLUTO_TILT   = 122.53
PLUTO_SPIN   = 0.050    # mutual tidal lock: matches Charon's orbit speed

# ------------------------------------------------------------------
# Charon:   Nearly spherical; gray-blue body + the famous Mordor Macula
#           – a dark reddish-brown north polar cap caused by tholins
#           deposited from Pluto's escaping atmosphere. Unique in the
#           solar system. Modelled here with a procedural polar cap.
# Styx:     Elongated, faint. (~10×7×5 km)
# Nix:      Clearly reddish-PINK – New Horizons confirmed a strong
#           pinkish/reddish hue, possibly methanol ice. (~50×35×33 km)
# Kerberos: Very dark, two-lobed snowman shape. (~19×10×9 km)
# Hydra:    Elongated, brighter than Nix/Kerberos. (~65×45×25 km)
# ------------------------------------------------------------------
MOONS = [
    # name       dark                  light                r     dist  orb     spin    scale              bumpy polar_cap
    ("Charon",  (0.30, 0.30, 0.34),  (0.58, 0.56, 0.62),  0.58, 3.4,  0.0500, 0.0500, (1.0,  1.0, 1.0),  False, (0.26, 0.10, 0.07)),
    ("Styx",    (0.15, 0.14, 0.16),  (0.38, 0.36, 0.40),  0.13, 5.8,  0.0159, 0.0159, (1.80, 1.0, 0.65), True,  None),
    ("Nix",     (0.50, 0.28, 0.24),  (0.80, 0.54, 0.46),  0.16, 7.2,  0.0128, 0.0128, (1.55, 1.0, 0.72), True,  None),
    ("Kerberos",(0.08, 0.07, 0.08),  (0.28, 0.25, 0.28),  0.12, 9.0,  0.0099, 0.0099, (1.60, 1.0, 0.72), True,  None),
    ("Hydra",   (0.36, 0.35, 0.38),  (0.73, 0.72, 0.76),  0.16, 11.0, 0.0083, 0.0083, (1.65, 1.0, 0.62), True,  None),
]

# ============================================================
# CLEAR SCENE
# ============================================================
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for col in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.lights):
    for b in col:
        if b.users == 0: col.remove(b)

# ============================================================
# HELPERS
# ============================================================

def make_sphere(name, radius, location):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, segments=128, ring_count=64, location=location)
    obj = bpy.context.object; obj.name = name
    bpy.ops.object.shade_smooth(); return obj


def make_moon_object(name, radius, location, scale=(1.0,1.0,1.0), bumpy=False):
    segs = 48 if bumpy else 96; rings = 24 if bumpy else 48
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, segments=segs, ring_count=rings, location=location)
    obj = bpy.context.object; obj.name = name; obj.scale = scale
    if bumpy:
        sub = obj.modifiers.new("Subsurf", 'SUBSURF')
        sub.levels = 2; sub.render_levels = 3
        disp_tex = bpy.data.textures.new(name+"_disp", 'CLOUDS')
        disp_tex.noise_scale = 0.40 + (hash(name)%6)*0.07; disp_tex.noise_depth = 4
        disp = obj.modifiers.new("Displace", 'DISPLACE')
        disp.texture = disp_tex; disp.strength = radius*0.42; disp.texture_coords = 'LOCAL'
    bpy.ops.object.shade_smooth(); return obj


def make_image_material(name, texture_path):
    mat = bpy.data.materials.new(name); mat.use_nodes = True
    nodes = mat.node_tree.nodes; links = mat.node_tree.links; nodes.clear()
    tex = nodes.new("ShaderNodeTexImage"); bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    out = nodes.new("ShaderNodeOutputMaterial")
    tex.location=(-500,0); bsdf.location=(-100,0); out.location=(250,0)
    try: tex.image = bpy.data.images.load(texture_path, check_existing=True)
    except Exception as e: print(f"[WARNING] '{texture_path}': {e}")
    bsdf.inputs["Roughness"].default_value = 0.88
    if "Specular IOR Level" in bsdf.inputs: bsdf.inputs["Specular IOR Level"].default_value = 0.04
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"]); return mat


def make_proc_moon_material(name, dark_col, light_col, noise_scale=6.5, polar_cap=None):
    """
    Procedural moon material with optional polar cap color (used for Charon's Mordor Macula).
    polar_cap: RGB tuple for the cap color, or None.
    """
    mat = bpy.data.materials.new(f"{name} Material"); mat.use_nodes = True
    nodes = mat.node_tree.nodes; links = mat.node_tree.links; nodes.clear()

    coord      = nodes.new("ShaderNodeTexCoord")
    noise_col  = nodes.new("ShaderNodeTexNoise")
    noise_bump = nodes.new("ShaderNodeTexNoise")
    ramp       = nodes.new("ShaderNodeValToRGB")
    bump       = nodes.new("ShaderNodeBump")
    bsdf       = nodes.new("ShaderNodeBsdfPrincipled")
    out        = nodes.new("ShaderNodeOutputMaterial")

    coord.location=(-900,0); noise_col.location=(-650,180); noise_bump.location=(-650,-150)
    ramp.location=(-380,180); bump.location=(-380,-150); bsdf.location=(-80,0); out.location=(220,0)

    noise_col.inputs["Scale"].default_value = noise_scale
    noise_col.inputs["Detail"].default_value = 10.0
    noise_col.inputs["Roughness"].default_value = 0.68
    noise_col.inputs["Distortion"].default_value = 0.25
    noise_bump.inputs["Scale"].default_value = noise_scale*2.8
    noise_bump.inputs["Detail"].default_value = 8.0
    noise_bump.inputs["Roughness"].default_value = 0.78
    ramp.color_ramp.elements[0].position = 0.28
    ramp.color_ramp.elements[0].color    = (*dark_col,  1.0)
    ramp.color_ramp.elements[1].position = 0.74
    ramp.color_ramp.elements[1].color    = (*light_col, 1.0)
    bump.inputs["Strength"].default_value = 0.65
    bump.inputs["Distance"].default_value = 0.08
    bsdf.inputs["Roughness"].default_value = 0.90
    if "Specular IOR Level" in bsdf.inputs: bsdf.inputs["Specular IOR Level"].default_value = 0.02

    links.new(coord.outputs["Object"],   noise_col.inputs["Vector"])
    links.new(coord.outputs["Object"],   noise_bump.inputs["Vector"])
    links.new(noise_col.outputs["Fac"],  ramp.inputs["Fac"])
    links.new(noise_bump.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"],    bsdf.inputs["Normal"])

    if polar_cap:
        # Use Generated Y coordinate (0 = south pole, 1 = north pole)
        # to paint Mordor Macula as a dark reddish-brown north polar cap.
        coord_gen  = nodes.new("ShaderNodeTexCoord")
        sep_xyz    = nodes.new("ShaderNodeSeparateXYZ")
        cap_ramp   = nodes.new("ShaderNodeValToRGB")
        cap_mix    = nodes.new("ShaderNodeMixRGB")

        coord_gen.location = (-900, -300)
        sep_xyz.location   = (-650, -300)
        cap_ramp.location  = (-380, -320)
        cap_mix.location   = (-80,  -180)

        links.new(coord_gen.outputs["Generated"], sep_xyz.inputs["Vector"])
        links.new(sep_xyz.outputs["Y"], cap_ramp.inputs["Fac"])

        # Cap is fully visible above Y=0.78 (northern ~40% of sphere)
        cap_ramp.color_ramp.elements[0].position = 0.62
        cap_ramp.color_ramp.elements[0].color    = (0, 0, 0, 1)  # no cap
        cap_ramp.color_ramp.elements[1].position = 0.80
        cap_ramp.color_ramp.elements[1].color    = (1, 1, 1, 1)  # full cap

        cap_mix.blend_type = 'MIX'
        cap_mix.inputs["Color2"].default_value = (*polar_cap, 1.0)

        links.new(ramp.outputs["Color"],     cap_mix.inputs["Color1"])
        links.new(cap_ramp.outputs["Color"], cap_mix.inputs["Fac"])
        links.new(cap_mix.outputs["Color"],  bsdf.inputs["Base Color"])
    else:
        links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])

    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


def add_driver(obj, path, index, expression):
    obj.driver_add(path, index).driver.expression = expression


def make_orbit_ring(name, radius, color=(0.28,0.28,0.38), segments=128):
    verts = [(math.cos(2*math.pi*i/segments)*radius,
              math.sin(2*math.pi*i/segments)*radius, 0) for i in range(segments)]
    mesh = bpy.data.meshes.new(name+"_mesh"); obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    mesh.from_pydata(verts, [(i,(i+1)%segments) for i in range(segments)], [])
    mesh.update()
    mat = bpy.data.materials.new(name+"_mat"); mat.use_nodes = True
    mat.node_tree.nodes.clear()
    emit = mat.node_tree.nodes.new("ShaderNodeEmission")
    out2 = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
    emit.inputs["Color"].default_value=(*color,1); emit.inputs["Strength"].default_value=0.15
    mat.node_tree.links.new(emit.outputs["Emission"], out2.inputs["Surface"])
    obj.data.materials.append(mat); return obj

# ============================================================
# PLUTO
# ============================================================
pluto = make_sphere("Pluto", PLUTO_RADIUS, (0,0,0))
pluto.rotation_euler[0] = math.radians(PLUTO_TILT)
pluto.data.materials.append(make_image_material("Pluto Material", PLUTO_TEXTURE))
add_driver(pluto, "rotation_euler", 2, f"frame*-{PLUTO_SPIN}")

# ============================================================
# MOONS
# ============================================================
for (name, dark, light, radius, dist, orb_spd, spin_spd, shp, bumpy, cap) in MOONS:
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
    orbit_empty = bpy.context.object; orbit_empty.name = f"{name} Orbit"
    orbit_empty.rotation_euler[0] = math.radians(PLUTO_TILT + (hash(name)%5-2)*0.3)
    add_driver(orbit_empty, "rotation_euler", 2, f"frame*{orb_spd}")

    moon = make_moon_object(name, radius, (0,dist,0), scale=shp, bumpy=bumpy)
    moon.parent = orbit_empty
    moon.matrix_parent_inverse = orbit_empty.matrix_world.inverted()
    moon.data.materials.append(make_proc_moon_material(name, dark, light, polar_cap=cap))
    add_driver(moon, "rotation_euler", 2, f"frame*{spin_spd}")

    ring_col = (0.40,0.38,0.45) if name == "Charon" else (0.22,0.22,0.32)
    make_orbit_ring(f"{name} Ring", dist, color=ring_col)

print(f"Pluto scene ready – Pluto + {len(MOONS)} moons.")
print("  Charon: Mordor Macula polar cap rendered via procedural north-pole mask.")
print("  Nix: pink/reddish surface from methanol ice (New Horizons confirmed).")
print("  Styx, Kerberos, Hydra: elongated irregular shapes from real axis ratios.")

# ============================================================
# STAR BACKGROUND
# ============================================================
world = bpy.context.scene.world; world.use_nodes = True
wnodes = world.node_tree.nodes; wlinks = world.node_tree.links; wnodes.clear()
env = wnodes.new("ShaderNodeTexEnvironment"); bg = wnodes.new("ShaderNodeBackground")
out = wnodes.new("ShaderNodeOutputWorld")
env.location=(-400,0); bg.location=(-100,0); out.location=(200,0)
try: env.image = bpy.data.images.load(STAR_TEXTURE, check_existing=True)
except Exception as e: print(f"[WARNING] {e}"); bg.inputs["Color"].default_value=(0.005,0.005,0.012,1)
bg.inputs["Strength"].default_value = 1.3
wlinks.new(env.outputs["Color"], bg.inputs["Color"])
wlinks.new(bg.outputs["Background"], out.inputs["Surface"])

bpy.ops.object.light_add(type='SUN', location=(0,80,20))
sun = bpy.context.object; sun.name = "Sun Light"
sun.data.energy = 1.2; sun.rotation_euler = (math.radians(-70),0,0)

bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
cam_orbit = bpy.context.object; cam_orbit.name = "Camera Orbit"
add_driver(cam_orbit, "rotation_euler", 2, "frame * 0.006")
cam_data = bpy.data.cameras.new("Camera"); cam_data.lens = 28
camera = bpy.data.objects.new("Camera", cam_data)
bpy.context.collection.objects.link(camera)
camera.location = (22, 0, 5)
camera.parent = cam_orbit
camera.matrix_parent_inverse = cam_orbit.matrix_world.inverted()
track = camera.constraints.new('TRACK_TO')
track.target = pluto; track.track_axis = 'TRACK_NEGATIVE_Z'; track.up_axis = 'UP_Y'
bpy.context.scene.camera = camera

scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE'; scene.cycles.samples = 256
scene.render.resolution_x = 768; scene.render.resolution_y = 432
scene.frame_start = 1; scene.frame_end = 250