import bpy
import math

# ============================================================
# TEXTURE PATHS  –  planet only; moons are procedural
# ============================================================

BASE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures"

NEPTUNE_TEXTURE = BASE + r"\neptune.jpg"
STAR_TEXTURE    = BASE + r"\2k_stars.jpg"

# ============================================================
# SCENE SCALE (relative, NOT real km)
# ============================================================

NEPTUNE_RADIUS = 2.5
NEPTUNE_TILT   = 28.32
NEPTUNE_SPIN   = 0.068

# ------------------------------------------------------------------
# Moon catalogue
# (name, dark_color, light_color, radius, orbit_dist, orb_speed, spin_speed)
# Triton: pinkish nitrogen-ice surface, RETROGRADE orbit (negative speed)
# Proteus: very dark irregular body
# Nereid: distant, slow, neutral gray
# ------------------------------------------------------------------

MOONS = [
    ("Proteus", (0.06, 0.06, 0.07), (0.24, 0.22, 0.22), 0.26,  6.5,  0.0210,  0.0210),
    ("Triton",  (0.68, 0.52, 0.48), (0.95, 0.90, 0.88), 0.52, 11.0, -0.0090, -0.0090),
    ("Nereid",  (0.22, 0.22, 0.26), (0.50, 0.48, 0.52), 0.20, 30.0,  0.0009,  0.0009),
]

# ============================================================
# CLEAR SCENE
# ============================================================

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for collection in (bpy.data.meshes, bpy.data.materials,
                   bpy.data.images, bpy.data.lights):
    for block in collection:
        if block.users == 0:
            collection.remove(block)

# ============================================================
# HELPERS
# ============================================================

def make_sphere(name, radius, location):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, segments=128, ring_count=64, location=location)
    obj = bpy.context.object
    obj.name = name
    bpy.ops.object.shade_smooth()
    return obj


def make_image_material(name, texture_path):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    tex  = nodes.new("ShaderNodeTexImage")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    out  = nodes.new("ShaderNodeOutputMaterial")
    tex.location  = (-500, 0); bsdf.location = (-100, 0); out.location = (250, 0)
    try:
        tex.image = bpy.data.images.load(texture_path, check_existing=True)
    except Exception as e:
        print(f"[WARNING] Couldn't load '{texture_path}': {e}")
    bsdf.inputs["Roughness"].default_value = 0.8
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.05
    links.new(tex.outputs["Color"],  bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"],  out.inputs["Surface"])
    return mat


def make_proc_moon_material(name, dark_col, light_col, noise_scale=6.0):
    """Procedural icy/rocky moon – no texture file needed."""
    mat = bpy.data.materials.new(f"{name} Material")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    coord      = nodes.new("ShaderNodeTexCoord")
    noise_col  = nodes.new("ShaderNodeTexNoise")
    noise_bump = nodes.new("ShaderNodeTexNoise")
    ramp       = nodes.new("ShaderNodeValToRGB")
    bump       = nodes.new("ShaderNodeBump")
    bsdf       = nodes.new("ShaderNodeBsdfPrincipled")
    out        = nodes.new("ShaderNodeOutputMaterial")

    coord.location      = (-900,   0)
    noise_col.location  = (-650, 180)
    noise_bump.location = (-650,-150)
    ramp.location       = (-380, 180)
    bump.location       = (-380,-150)
    bsdf.location       = (-80,   0)
    out.location        = ( 220,   0)

    noise_col.inputs["Scale"].default_value      = noise_scale
    noise_col.inputs["Detail"].default_value     = 10.0
    noise_col.inputs["Roughness"].default_value  = 0.68
    noise_col.inputs["Distortion"].default_value = 0.25

    noise_bump.inputs["Scale"].default_value     = noise_scale * 2.8
    noise_bump.inputs["Detail"].default_value    = 8.0
    noise_bump.inputs["Roughness"].default_value = 0.78

    ramp.color_ramp.elements[0].position = 0.28
    ramp.color_ramp.elements[0].color    = (*dark_col,  1.0)
    ramp.color_ramp.elements[1].position = 0.74
    ramp.color_ramp.elements[1].color    = (*light_col, 1.0)

    bump.inputs["Strength"].default_value = 0.65
    bump.inputs["Distance"].default_value = 0.08

    bsdf.inputs["Roughness"].default_value = 0.88
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.03

    links.new(coord.outputs["Object"],   noise_col.inputs["Vector"])
    links.new(coord.outputs["Object"],   noise_bump.inputs["Vector"])
    links.new(noise_col.outputs["Fac"],  ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"],     bsdf.inputs["Base Color"])
    links.new(noise_bump.outputs["Fac"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"],    bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"],      out.inputs["Surface"])

    return mat


def add_driver(obj, path, index, expression):
    drv = obj.driver_add(path, index).driver
    drv.expression = expression


def make_orbit_ring(name, radius, color=(0.20, 0.30, 0.55), segments=128):
    verts = [(math.cos(2*math.pi*i/segments)*radius,
              math.sin(2*math.pi*i/segments)*radius, 0)
             for i in range(segments)]
    mesh = bpy.data.meshes.new(name + "_mesh")
    obj  = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    edges = [(i, (i+1) % segments) for i in range(segments)]
    mesh.from_pydata(verts, edges, [])
    mesh.update()
    mat = bpy.data.materials.new(name + "_mat")
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    emit = mat.node_tree.nodes.new("ShaderNodeEmission")
    out2 = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
    emit.inputs["Color"].default_value    = (*color, 1)
    emit.inputs["Strength"].default_value = 0.15
    mat.node_tree.links.new(emit.outputs["Emission"], out2.inputs["Surface"])
    obj.data.materials.append(mat)
    return obj

# ============================================================
# NEPTUNE
# ============================================================

neptune = make_sphere("Neptune", NEPTUNE_RADIUS, (0, 0, 0))
neptune.rotation_euler[0] = math.radians(NEPTUNE_TILT)
neptune.data.materials.append(make_image_material("Neptune Material", NEPTUNE_TEXTURE))
add_driver(neptune, "rotation_euler", 2, f"frame*{NEPTUNE_SPIN}")

# ============================================================
# MOONS
# ============================================================

for (name, dark, light, radius, dist, orb_spd, spin_spd) in MOONS:
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    orbit_empty = bpy.context.object
    orbit_empty.name = f"{name} Orbit"
    orbit_empty.rotation_euler[0] = math.radians(
        NEPTUNE_TILT + (hash(name) % 7 - 3) * 0.5)
    add_driver(orbit_empty, "rotation_euler", 2, f"frame*{orb_spd}")

    moon = make_sphere(name, radius, (0, dist, 0))
    moon.parent = orbit_empty
    moon.matrix_parent_inverse = orbit_empty.matrix_world.inverted()
    moon.data.materials.append(make_proc_moon_material(name, dark, light))
    add_driver(moon, "rotation_euler", 2, f"frame*{spin_spd}")

    make_orbit_ring(f"{name} Ring", dist)

print(f"Neptune scene created successfully. • Neptune + {len(MOONS)} moons added.")
print("  NOTE: Triton orbits retrograde (negative speed) –")
print("        its pinkish nitrogen-ice surface is reflected in the color palette.")

# ============================================================
# STAR BACKGROUND
# ============================================================

world = bpy.context.scene.world
world.use_nodes = True
wnodes = world.node_tree.nodes
wlinks = world.node_tree.links
wnodes.clear()
env = wnodes.new("ShaderNodeTexEnvironment")
bg  = wnodes.new("ShaderNodeBackground")
out = wnodes.new("ShaderNodeOutputWorld")
env.location = (-400, 0); bg.location = (-100, 0); out.location = (200, 0)
try:
    env.image = bpy.data.images.load(STAR_TEXTURE, check_existing=True)
except Exception as e:
    print(f"[WARNING] Star texture failed: {e}")
    bg.inputs["Color"].default_value = (0.01, 0.01, 0.03, 1)
bg.inputs["Strength"].default_value = 1.3
wlinks.new(env.outputs["Color"],     bg.inputs["Color"])
wlinks.new(bg.outputs["Background"], out.inputs["Surface"])

# ============================================================
# SUN LIGHT  (faintest of the three – Neptune is the most distant)
# ============================================================

bpy.ops.object.light_add(type='SUN', location=(0, 80, 20))
sun = bpy.context.object
sun.name = "Sun Light"
sun.data.energy = 2.2
sun.rotation_euler = (math.radians(-70), 0, 0)

# ============================================================
# CAMERA  –  cinematic low-angle slow orbit, deep space feel
# ============================================================

bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
cam_orbit = bpy.context.object
cam_orbit.name = "Camera Orbit"
add_driver(cam_orbit, "rotation_euler", 2, "frame * 0.005")

cam_data = bpy.data.cameras.new("Camera")
cam_data.lens = 52
camera = bpy.data.objects.new("Camera", cam_data)
bpy.context.collection.objects.link(camera)

# Very low angle – horizon-level view of Neptune against deep space,
# Triton sweeping past in the mid-ground, Nereid visible in the far field
camera.location = (44, 0, 6)
camera.parent   = cam_orbit
camera.matrix_parent_inverse = cam_orbit.matrix_world.inverted()

track = camera.constraints.new('TRACK_TO')
track.target     = neptune
track.track_axis = 'TRACK_NEGATIVE_Z'
track.up_axis    = 'UP_Y'

bpy.context.scene.camera = camera

# ============================================================
# RENDER SETTINGS
# ============================================================

scene = bpy.context.scene
scene.render.engine       = 'BLENDER_EEVEE'
scene.cycles.samples      = 256
scene.render.resolution_x = 768
scene.render.resolution_y = 432
scene.frame_start         = 1
scene.frame_end           = 250