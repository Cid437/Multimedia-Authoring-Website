import bpy
import math

# ============================================================
# TEXTURE PATHS  –  fill these in before running
# ============================================================

BASE = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures"

JUPITER_TEXTURE  = BASE + r"\jupiter.jpg"
IO_TEXTURE       = BASE + r"\io.jpg"
EUROPA_TEXTURE   = BASE + r"\europa.jpg"
GANYMEDE_TEXTURE = BASE + r"\ganymede.jpg"
CALLISTO_TEXTURE = BASE + r"\callisto.jpg"
MOON_TEXTURE     = BASE + r"\moon.jpg"          # fallback for smaller moons
STAR_TEXTURE     = BASE + r"\2k_stars.jpg"

# ============================================================
# SCENE SCALE (relative, NOT real km)
# ============================================================

JUPITER_RADIUS = 4.0          # reference unit

JUPITER_TILT   = 3.13         # degrees (nearly upright)
JUPITER_SPIN   = 0.12         # fastest spinner in the solar system

# ------------------------------------------------------------------
# Moon catalogue
# Each entry:  (name, texture, radius, orbit_distance, orbit_speed, spin_speed)
#
# orbit_speed  – degrees per frame (smaller = slower)
# spin_speed   – tidal-lock approximation (= orbit_speed for most)
# orbit_distance is in scene units relative to JUPITER_RADIUS
# ------------------------------------------------------------------

MOONS = [
    # Inner small moons
    ("Metis",    MOON_TEXTURE,     0.07,  5.0,   0.0420, 0.0420),
    ("Amalthea", MOON_TEXTURE,     0.12,  5.8,   0.0360, 0.0360),
    ("Thebe",    MOON_TEXTURE,     0.10,  6.8,   0.0300, 0.0300),

    # Galilean moons  (the big four)
    ("Io",       IO_TEXTURE,       0.50,  8.5,   0.0220, 0.0220),
    ("Europa",   EUROPA_TEXTURE,   0.43,  11.5,  0.0130, 0.0130),
    ("Ganymede", GANYMEDE_TEXTURE, 0.72,  16.0,  0.0070, 0.0070),
    ("Callisto", CALLISTO_TEXTURE, 0.66,  22.0,  0.0035, 0.0035),

    # Mid-range moon
    ("Himalia",  MOON_TEXTURE,     0.08,  32.0,  0.0012, 0.0012),
]

# ============================================================
# CLEAR SCENE
# ============================================================

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

for collection in (
    bpy.data.meshes,
    bpy.data.materials,
    bpy.data.images,
    bpy.data.lights,
):
    for block in collection:
        if block.users == 0:
            collection.remove(block)

# ============================================================
# HELPERS
# ============================================================

def make_sphere(name, radius, location):
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius,
        segments=128,
        ring_count=64,
        location=location,
    )
    obj = bpy.context.object
    obj.name = name
    bpy.ops.object.shade_smooth()
    return obj


def make_material(name, texture_path):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    tex  = nodes.new("ShaderNodeTexImage")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    out  = nodes.new("ShaderNodeOutputMaterial")

    tex.location  = (-500, 0)
    bsdf.location = (-100, 0)
    out.location  = ( 250, 0)

    try:
        tex.image = bpy.data.images.load(texture_path, check_existing=True)
    except Exception as e:
        print(f"[WARNING] Couldn't load texture '{texture_path}': {e}")

    bsdf.inputs["Roughness"].default_value = 0.8
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = 0.05

    links.new(tex.outputs["Color"],  bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"],  out.inputs["Surface"])

    return mat


def add_driver(obj, path, index, expression):
    drv = obj.driver_add(path, index).driver
    drv.expression = expression


def make_orbit_ring(name, radius, segments=128):
    """Draw a thin visual guide circle for one moon's orbit."""
    verts = []
    for i in range(segments):
        angle = 2 * math.pi * i / segments
        verts.append((math.cos(angle) * radius, math.sin(angle) * radius, 0))

    mesh = bpy.data.meshes.new(name + "_mesh")
    obj  = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    edges = [(i, (i + 1) % segments) for i in range(segments)]
    mesh.from_pydata(verts, edges, [])
    mesh.update()

    # Simple emission material so rings are visible but not bright
    mat = bpy.data.materials.new(name + "_mat")
    mat.use_nodes = True
    mat.node_tree.nodes.clear()

    emit = mat.node_tree.nodes.new("ShaderNodeEmission")
    out2 = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
    emit.inputs["Color"].default_value   = (0.25, 0.25, 0.35, 1)
    emit.inputs["Strength"].default_value = 0.15
    mat.node_tree.links.new(emit.outputs["Emission"], out2.inputs["Surface"])
    obj.data.materials.append(mat)

    return obj

# ============================================================
# JUPITER
# ============================================================

jupiter = make_sphere("Jupiter", JUPITER_RADIUS, (0, 0, 0))
jupiter.rotation_euler[0] = math.radians(JUPITER_TILT)
jupiter.data.materials.append(
    make_material("Jupiter Material", JUPITER_TEXTURE)
)

# Jupiter Z-spin driver
add_driver(jupiter, "rotation_euler", 2, f"frame*{JUPITER_SPIN}")

# ============================================================
# MOONS  –  each gets its own orbit empty
# ============================================================

for (name, texture, radius, dist, orb_speed, spin_speed) in MOONS:

    # --- Orbit empty ----------------------------------------
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    orbit_empty = bpy.context.object
    orbit_empty.name = f"{name} Orbit"

    # Tilt each orbit plane slightly for visual interest
    orbit_empty.rotation_euler[0] = math.radians(
        JUPITER_TILT + (hash(name) % 7 - 3) * 0.4   # ±1.2° scatter
    )

    add_driver(orbit_empty, "rotation_euler", 2, f"frame*{orb_speed}")

    # --- Moon sphere ----------------------------------------
    moon = make_sphere(name, radius, (0, dist, 0))
    moon.parent = orbit_empty
    moon.matrix_parent_inverse = orbit_empty.matrix_world.inverted()

    moon.data.materials.append(
        make_material(f"{name} Material", texture)
    )

    # Tidal-lock spin (Z relative to moon's own axis)
    add_driver(moon, "rotation_euler", 2, f"frame*{spin_speed}")

    # --- Visible orbit guide --------------------------------
    ring = make_orbit_ring(f"{name} Ring", dist)

print("Jupiter scene created successfully.")
print(f"  • Jupiter + {len(MOONS)} moons added.")
print("  TIP: In Timeline, set End Frame to 500+ for full orbit visibility.")

# ============================================================
# STAR BACKGROUND
# ============================================================

world = bpy.context.scene.world
world.use_nodes = True

wnodes = world.node_tree.nodes
wlinks = world.node_tree.links
wnodes.clear()

env = wnodes.new("ShaderNodeTexEnvironment")
bg  = wnodes.new("ShaderNodeBackground")
out = wnodes.new("ShaderNodeOutputWorld")

env.location = (-400, 0)
bg.location  = (-100, 0)
out.location = ( 200, 0)

try:
    env.image = bpy.data.images.load(STAR_TEXTURE, check_existing=True)
except Exception as e:
    print(f"[WARNING] Star texture failed: {e}")
    bg.inputs["Color"].default_value = (0.01, 0.01, 0.03, 1)

bg.inputs["Strength"].default_value = 1.3

wlinks.new(env.outputs["Color"],      bg.inputs["Color"])
wlinks.new(bg.outputs["Background"],  out.inputs["Surface"])

# ============================================================
# SUN LIGHT  (far off to simulate solar direction)
# ============================================================

bpy.ops.object.light_add(type='SUN', location=(0, 80, 20))
sun = bpy.context.object
sun.name = "Sun Light"
sun.data.energy = 6
sun.rotation_euler = (
    math.radians(-70),
    0,
    math.radians(0),
)

# ============================================================
# CAMERA  (pulled back further than Earth scene)
# ============================================================

bpy.ops.object.camera_add(location=(-60, 50, 15))
camera = bpy.context.object
camera.name = "Camera"
camera.rotation_euler = (
    math.radians(80),
    0,
    math.radians(230),
)
camera.data.lens = 55
bpy.context.scene.camera = camera

# ============================================================
# RENDER SETTINGS
# ============================================================

scene = bpy.context.scene
scene.render.engine         = 'BLENDER_EEVEE'
scene.cycles.samples        = 256
scene.render.resolution_x   = 640
scene.render.resolution_y   = 360
scene.frame_start           = 1
scene.frame_end             = 500