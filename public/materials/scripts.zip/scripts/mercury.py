import bpy
import math
# --------------------------------------------------
# CLEAR SCENE
# --------------------------------------------------
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
# --------------------------------------------------
# CREATE MERCURY
# --------------------------------------------------
bpy.ops.mesh.primitive_uv_sphere_add(
    segments=64,
    ring_count=32,
    radius=2,
    location=(0, 0, 0)
)
mercury = bpy.context.object
mercury.name = "Mercury"
bpy.ops.object.shade_smooth()
# --------------------------------------------------
# MATERIAL + TEXTURE
# --------------------------------------------------
mat = bpy.data.materials.new(name="MercuryMaterial")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
# Clear default nodes
nodes.clear()
# Nodes
tex = nodes.new(type="ShaderNodeTexImage")
bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
out = nodes.new(type="ShaderNodeOutputMaterial")
tex.location = (-400, 0)
bsdf.location = (0, 0)
out.location = (300, 0)
# IMAGE PATH (FIX THIS IF NEEDED)
image_path = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\mercury.jpg"
tex.image = bpy.data.images.load(image_path, check_existing=True)
# Connect nodes
links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
# Assign material
mercury.data.materials.clear()
mercury.data.materials.append(mat)
# --------------------------------------------------
# 🌌 STAR TEXTURE BACKGROUND
# --------------------------------------------------
world = bpy.context.scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links
# Clear existing nodes
nodes.clear()
# Create nodes
bg = nodes.new(type="ShaderNodeBackground")
env = nodes.new(type="ShaderNodeTexEnvironment")
out = nodes.new(type="ShaderNodeOutputWorld")
env.location = (-300, 0)
bg.location = (0, 0)
out.location = (200, 0)
# ⭐ CHANGE THIS PATH TO YOUR STAR TEXTURE
star_path = r"C:\BSIT-FILES\2Y3S\MultimediaAndAuthoring\solarsystem\planettextures\2k_stars.jpg"
# Load star image
env.image = bpy.data.images.load(star_path, check_existing=True)
# Connect nodes
links.new(env.outputs["Color"], bg.inputs["Color"])
links.new(bg.outputs["Background"], out.inputs["Surface"])
# Optional: adjust brightness
bg.inputs["Strength"].default_value = 1.5
# --------------------------------------------------
# LIGHTING (SUN)
# --------------------------------------------------
bpy.ops.object.light_add(type='SUN', location=(6, -6, 6))
sun = bpy.context.object
sun.data.energy = 6
sun.rotation_euler = (
    math.radians(45),
    0,
    math.radians(30)
)
# --------------------------------------------------
# CAMERA
# --------------------------------------------------
bpy.ops.object.camera_add(location=(0, -12, 2))
camera = bpy.context.object
camera.rotation_euler = (
    math.radians(80),
    0,
    0
)
bpy.context.scene.camera = camera
# --------------------------------------------------
# 🪐 CONSTANT ROTATION (NO KEYFRAMES, NO ERRORS)
# --------------------------------------------------
mercury.rotation_euler[2] = 0
driver = mercury.driver_add("rotation_euler", 2).driver
driver.expression = "frame * 0.0504"
# --------------------------------------------------
# WORLD / SPACE BACKGROUND
# --------------------------------------------------
world = bpy.context.scene.world
world.use_nodes = True
bg = world.node_tree.nodes["Background"]
bg.inputs[0].default_value = (0.01, 0.01, 0.03, 1)
print("Mercury created successfully with constant rotation (driver-based).")